import Card from './component/card';

function App() {
  return (
    <Card/>
  );
}

export default App;
